import { View, StyleSheet, Text } from "react-native"
import { EvilIcons } from "@expo/vector-icons"
import { useEffect, useState } from "react"
import { useLocalSearchParams } from "expo-router"
import { getPostDetail } from "@/api/boardList"

const LookBoard = () => {
  const { id } = useLocalSearchParams();
  const [post, setPost] = useState<any>(null);

  useEffect(() => {
    const fetchPost = async () => {
      try {
        const res = await getPostDetail(Number(id));
        setPost(res.data);
      } catch (err) {
        console.error("게시글상세조회실패: ", err);
      }
    }
    fetchPost();
  }, [id])

  if (!post) return <Text>불러오는 중...</Text>

  return (
    <View style={styles.container}>
      <View style={styles.border}>
        <Text style={styles.title}>{post.title}</Text>
      </View>
      <Text style={styles.text}>{post.body}</Text>
      <View style={styles.likeIcon}>
        <EvilIcons name="heart" size={44} />
        <Text style={{marginTop: -8}}>{post.like}</Text>
      </View>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    width: 370,
    flex: 1,
    backgroundColor: "#fff",
    borderRadius: 16,
    marginHorizontal: 'auto',
    marginTop: 16,
    padding: 10,
  },
  border: {          
    borderBottomWidth: 0.8,
    borderColor: '#DCDCDC',
  },
  title: {
    fontWeight: 'bold',
    fontSize: 24,
  },
  text: {
    paddingVertical: 20,
  },
  likeIcon: {
    alignItems: 'center',
  }
})

export default LookBoard;